#参考自：
#http://www.radacad.com/wp-content/uploads/2017/07/output_1499829426.htm



#########
library(rworldmap)
library(TeachingDemos)

#读取经纬度和物种丰度数据
df <- read.delim('species.txt', sep = '\t')

#指定物种颜色
spe <- c('species1', 'species2', 'species3')
color <- c('red', 'blue', 'green3')

##单个物种丰度的柱形图

#绘制地图
plot(getMap())

#使用循环，依次绘制各站点的物种丰度柱形图，并添加在地图中指定经纬度位置
for (i in 1:nrow(df)) {
    subplot(
        barplot(height = unlist(df[i,spe], use.names = FALSE), axes = TRUE, col = color, ylim = range(df[ ,spe]), cex.axis = 0.5, tck = -0.2, las = 1), 
        x = df[i,'LON'], y = df[i,'LAT'], size = c(0.3, 0.4)
    )
}

#添加图例
legend('right', legend = spe, fill = color)


##堆叠物种丰度柱形图

#绘制地图
plot(getMap())

#使用循环，依次绘制各站点的物种丰度堆叠柱形图，并添加在地图中指定经纬度位置
for (i in 1:nrow(df)) {
    subplot(
        barplot(t(as.matrix(df[i,spe])), axisnames = FALSE, axes = TRUE, col = color, ylim = range(df[ ,spe]), cex.axis = 0.5, tck = -0.3, las = 1), 
        x = df[i,'LON'], y = df[i,'LAT'], size = c(0.15, 0.4)
    )
}

#添加图例
legend('right', legend = spe, fill = color)


##物种丰度的饼图

#绘制地图
plot(getMap())

#使用循环，依次绘制各站点的物种丰度饼图，并添加在地图中指定经纬度位置
for (i in 1:nrow(df)) {
    subplot(
        pie(unlist(df[i,spe], use.names = FALSE), col = color, labels = NA),         
        x = df[i,'LON'], y = df[i,'LAT'], size = c(df[i,'total'],df[i,'total'])
    )
}

#添加图例
legend('right', legend = spe, fill = color)

