library(reshape2)
library(ggplot2)
library(patchwork)

#读取数据
dat <- read.delim('taxonomy.txt', stringsAsFactors = FALSE)

#按温度梯度对样本排序
dat <- dat[order(dat$temperature), ]
dat$NO <- 1:nrow(dat)

#转换为长列表格式便于 ggplot2 作图
dat <- melt(dat, id = c('NO', 'sample', 'temperature'))

#绘制物种丰度堆叠柱形图
p_bar <- ggplot(dat, aes(x = NO, y = value, fill = variable)) +
geom_col() +
scale_fill_manual(limits = c('class1', 'class2', 'class3', 'class4', 'class5', 'class6', 'class7', 'class8', 'class9'), 
    values = c('#9FCBE2', '#2D83BE', '#B3E08B', '#2FA128', '#FFE69A', '#FF8000', '#E41316', '#D22FF6', '#6A3A9B')) +
theme(panel.grid = element_blank(), 
    panel.background = element_rect(color = 'black', fill = 'white', size = 0.5), 
    axis.ticks = element_line(color = 'black', size = 0.5), 
    axis.text.x = element_text(color = 'black', size = 9), 
    axis.text.y = element_text(color = 'black', size = 9), 
    axis.title.y = element_text(color = 'black', size = 10),
    legend.text = element_text(color = 'black', size = 9), 
    legend.title = element_text(color = 'black', size = 10)) +
scale_x_continuous(breaks = unique(dat$NO), labels = unique(dat$sample), expand = expansion(mult = c(0.05, 0.05))) +
scale_y_continuous(expand = c(0, 0)) +
labs(x = '', y = 'Relative abundance', fill = 'Taxonomy')

p_bar

#绘制热图展示样本的温度梯度
p_temperature <- ggplot(dat, aes(x = NO, y = 1, fill = temperature)) +
geom_tile() +
scale_fill_gradientn(colors = colorRampPalette(c('#FAD9BA', '#C00216'))(20)) +
theme(panel.grid = element_blank(), 
    panel.background = element_blank(), 
    axis.ticks.x = element_line(color = 'black', size = 0.5), 
    axis.ticks.y = element_blank(), 
    axis.text.x = element_text(color = 'black', size = 9), 
    axis.text.y = element_blank(),
    legend.text = element_text(color = 'black', size = 9), 
    legend.title = element_text(color = 'black', size = 10)) +
scale_x_continuous(breaks = unique(dat$NO), labels = unique(dat$sample), expand = expansion(mult = c(0.05, 0.05))) +
scale_y_continuous(expand = expansion(mult = c(0, 0))) +
labs(x = '', y = '', fill = 'Temperature')

p_temperature

#将样本的温度梯度热图添加在丰度的堆叠柱形图下方
layout <- c(
	area(1, 1, 14, 10),
	area(15, 1, 15, 10)
)

p_bar + theme(axis.ticks.x = element_blank(), axis.text.x = element_blank()) +
p_temperature + plot_layout(design = layout)


#####################
#绘制物种丰度堆叠面积图
p_area <- ggplot(dat, aes(x = NO, y = value, fill = variable)) +
geom_area() +
scale_fill_manual(limits = c('class1', 'class2', 'class3', 'class4', 'class5', 'class6', 'class7', 'class8', 'class9'), 
    values = c('#9FCBE2', '#2D83BE', '#B3E08B', '#2FA128', '#FFE69A', '#FF8000', '#E41316', '#D22FF6', '#6A3A9B')) +
theme(panel.grid = element_blank(), 
    panel.background = element_rect(color = 'black', fill = 'white', size = 0.5), 
    axis.ticks = element_line(color = 'black', size = 0.5), 
    axis.text.x = element_text(color = 'black', size = 9), 
    axis.text.y = element_text(color = 'black', size = 9), 
    axis.title.y = element_text(color = 'black', size = 10),
    legend.text = element_text(color = 'black', size = 9), 
    legend.title = element_text(color = 'black', size = 10)) +
scale_x_continuous(breaks = unique(dat$NO), labels = unique(dat$sample), expand = expansion(mult = c(0.05, 0.05))) +
scale_y_continuous(expand = c(0, 0)) +
labs(x = '', y = 'Relative abundance', fill = 'Taxonomy')

p_area

#将刚才绘制的样本的温度梯度热图添加在丰度的堆叠面积图下方
p_area + theme(axis.ticks.x = element_blank(), axis.text.x = element_blank()) +
p_temperature + plot_layout(design = layout)

#####################
library(ggalluvial)

#绘制物种丰度冲击图代替堆叠面积图
p_flow1 <- ggplot(dat, aes(x = NO, y = value, fill = variable, alluvium = variable)) +
geom_flow(alpha = 1, width = 0) +
scale_fill_manual(limits = c('class1', 'class2', 'class3', 'class4', 'class5', 'class6', 'class7', 'class8', 'class9'), 
    values = c('#9FCBE2', '#2D83BE', '#B3E08B', '#2FA128', '#FFE69A', '#FF8000', '#E41316', '#D22FF6', '#6A3A9B')) +
theme(panel.grid = element_blank(), 
    panel.background = element_rect(color = 'black', fill = 'white', size = 0.5), 
    axis.ticks = element_line(color = 'black', size = 0.5), 
    axis.text.x = element_text(color = 'black', size = 9), 
    axis.text.y = element_text(color = 'black', size = 9), 
    axis.title.y = element_text(color = 'black', size = 10),
    legend.text = element_text(color = 'black', size = 9), 
    legend.title = element_text(color = 'black', size = 10)) +
scale_x_continuous(breaks = unique(dat$NO), labels = unique(dat$sample), expand = expansion(mult = c(0.05, 0.05))) +
scale_y_continuous(expand = c(0, 0)) +
labs(x = '', y = 'Relative abundance', fill = 'Taxonomy')

p_flow1

#将刚才绘制的样本的温度梯度热图添加在丰度的冲击图下方
p_flow1 + theme(axis.ticks.x = element_blank(), axis.text.x = element_blank()) +
p_temperature + plot_layout(design = layout)

#物种丰度堆叠柱形图+冲击图
p_flow2 <- ggplot(dat, aes(x = NO, y = value, fill = variable, stratum = variable, alluvium = variable)) +
geom_stratum(width = 0.7) +
geom_flow(alpha = 0.5) +
scale_fill_manual(limits = c('class1', 'class2', 'class3', 'class4', 'class5', 'class6', 'class7', 'class8', 'class9'), 
    values = c('#9FCBE2', '#2D83BE', '#B3E08B', '#2FA128', '#FFE69A', '#FF8000', '#E41316', '#D22FF6', '#6A3A9B')) +
theme(panel.grid = element_blank(), 
    panel.background = element_rect(color = 'black', fill = 'white', size = 0.5), 
    axis.ticks = element_line(color = 'black', size = 0.5), 
    axis.text.x = element_text(color = 'black', size = 9), 
    axis.text.y = element_text(color = 'black', size = 9), 
    axis.title.y = element_text(color = 'black', size = 10),
    legend.text = element_text(color = 'black', size = 9), 
    legend.title = element_text(color = 'black', size = 10)) +
scale_x_continuous(breaks = unique(dat$NO), labels = unique(dat$sample), expand = expansion(mult = c(0.05, 0.05))) +
scale_y_continuous(expand = c(0, 0)) +
labs(x = '', y = 'Relative abundance', fill = 'Taxonomy')

p_flow2

#将刚才绘制的样本的温度梯度热图添加在丰度的冲击图下方
p_flow2 + theme(axis.ticks.x = element_blank(), axis.text.x = element_blank()) +
p_temperature + plot_layout(design = layout)
