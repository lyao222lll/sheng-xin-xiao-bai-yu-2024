##将一个 ceRNA 网络图以冲击图展示
library(reshape2)
library(ggalluvial)

#读取数据，lncRNA-miRNA-mRNA 的关系表
ceRNA <- read.csv('ceRNA.csv', stringsAsFactors = FALSE)

#预指定颜色，这个示例中 lncRNA、miRNA 和 mRNA 总计 36 个，需指定 36 种颜色
color <- c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', 
'#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', '#FFED6F', '#E41A1C', 
'#377EB8', '#4DAF4A', '#984EA3', '#FF7F00', '#FFFF33', '#A65628', 
'#F781BF', '#66C2A5', '#6181BD', '#F34800', '#64A10E', '#FF00FF', 
'#c7475b', '#049a0b', '#BEAED4', '#FDC086', '#FFFF99', '#386CB0', 
'#4253ff', '#ff4308', '#D8D155', '#F0027F', '#9FAED4', '#F7CDBD')

#整理为 ggplot2 的作图格式
ceRNA$link <- 1
ceRNA <- melt(ceRNA, id = 'link')
variable <- summary(ceRNA$variable)
ceRNA$flow <- rep(1:variable[1], length(variable))
head(ceRNA)  #查看整理后的数据结构

#绘制冲击图展示 lncRNA-miRNA-mRNA 的关系网络
ggplot(ceRNA, aes(x = variable, y = link, stratum = value, alluvium = flow, fill = value)) +
geom_stratum() +  #冲击图中的堆叠柱形图
geom_flow(aes.flow = 'forward') +  #冲击图连线绘制
scale_fill_manual(values = color) +  #颜色赋值
geom_text(stat = 'stratum', infer.label = TRUE, size = 2.5) +  #添加 lncRNA、miRNA 和 mRNA 标签
scale_x_discrete(limits = c('lncRNA', 'miRNA', 'mRNA')) +  #定义 lncRNA、miRNA 和 mRNA 列的展示顺序
theme(legend.position = 'none', panel.background = element_blank(), line = element_blank(), axis.text.y = element_blank()) +
labs(x = '', y = '')


##另一种画法

#读取数据，lncRNA-miRNA-mRNA 的关系表
ceRNA <- read.csv('ceRNA.csv', stringsAsFactors = FALSE)

#预指定颜色，这个示例中 lncRNA、miRNA 和 mRNA 总计 36 个，需指定 36 种颜色
color <- c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', 
'#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', '#FFED6F', '#E41A1C', 
'#377EB8', '#4DAF4A', '#984EA3', '#FF7F00', '#FFFF33', '#A65628', 
'#F781BF', '#66C2A5', '#6181BD', '#F34800', '#64A10E', '#FF00FF', 
'#c7475b', '#049a0b', '#BEAED4', '#FDC086', '#FFFF99', '#386CB0', 
'#4253ff', '#ff4308', '#D8D155', '#F0027F', '#9FAED4', '#F7CDBD')

#重新定义堆叠图的高度值，以及连接流
ceRNA$link <- 1
ceRNA <- reshape::melt(ceRNA, id = 'link')

variable <- summary(ceRNA$variable)
ceRNA$flow <- rep(1:variable[1], length(variable))

link <- 1 / table(ceRNA$value)
for (i in names(link)) ceRNA[which(ceRNA$value == i),'link'] <- link[i]

#绘制冲击图展示 lncRNA-miRNA-mRNA 的关系网络
ggplot(ceRNA, aes(x = variable, y = link, stratum = value, alluvium = flow, fill = value)) +
geom_stratum() +  #冲击图中的堆叠柱形图
geom_flow(aes.flow = 'forward') +  #冲击图连线绘制
scale_fill_manual(values = color) +  #颜色赋值
geom_text(stat = 'stratum', infer.label = TRUE, size = 2.5) +  #添加 lncRNA、miRNA 和 mRNA 标签
scale_x_discrete(limits = c('lncRNA', 'miRNA', 'mRNA')) +  #定义 lncRNA、miRNA 和 mRNA 列的展示顺序
theme(legend.position = 'none', panel.background = element_blank(), line = element_blank(), axis.text.y = element_blank()) +
labs(x = '', y = '')

