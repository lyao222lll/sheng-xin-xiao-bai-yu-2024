#创建一个路径，存放下载 WebLogo
mkdir weblogo
cd weblogo
wget http://weblogo.berkeley.edu/release/weblogo.2.8.2.tar.gz
tar -vxzf weblogo.2.8.2.tar.gz

#添加可执行权限
chmod 777 weblogo/*

#查看程序帮助
weblogo/seqlogo -h

#调用 WebLogo 程序读取 FASTA 文件并绘制序列 Logo 的一个简单示例
#WebLogo 将识别这些序列中的保守性位置和变异位置，以及计算信息熵并生成序列 Logo
weblogo/seqlogo -F PDF -f test.fasta > globin.pdf   
weblogo/seqlogo -F PNG -f test.fasta > globin.png

